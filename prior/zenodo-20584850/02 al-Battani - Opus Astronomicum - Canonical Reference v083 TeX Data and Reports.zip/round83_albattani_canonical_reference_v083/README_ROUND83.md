# Round 83 - al-Battani canonical reference v0.83

Single top-level folder packaging is preserved.

Public PDFs are in:

`al-battani-opus-astronomicum/canonical-reference-v083/draft-pdfs/`

This round refines integration between the translated text and the table layer. It adds a text-table concordance and a professionally re-typeset table supplement. The public table supplement remains generated text: no screenshot gallery, no raw scan wrapper, no public source-plate pages.

Public PDFs:

- `al_battani_segments_01_100_modern_tex_text_only.pdf`
- `al_battani_table_reference_supplement_v083.pdf`
- `al_battani_opus_astronomicum_canonical_reference_v083.pdf`

Structured data is under `structured-data/`, including the text-table concordance and the full typed/numerical registers.

Checks are under `reports/`.
